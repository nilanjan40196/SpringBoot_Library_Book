package com.capg.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.capg.model.Book;
import com.capg.model.Library;
import com.capg.service.BookService;
import com.capg.service.LibraryService;

@RestController
public class Lib_Book_Controller {
	
	@Autowired
	LibraryService libService;
	
	@Autowired
	private BookService bookService;
	
	@RequestMapping("/")
	public ModelAndView home() {
		System.out.println("inside home");
		ModelAndView mv = new ModelAndView("home");
		List<Library> libs = libService.getAllLibrary();
		List<Book> books = bookService.gelAllBooks();
		mv.addObject("libraries", libs);
		mv.addObject("books", books);
		return mv;
	}
	
	@GetMapping("/getLibs")
	public List<Library> getAllLibrary(){
		return libService.getAllLibrary();	
	}
	
	@RequestMapping("/newLib")
	public ModelAndView getNewLibrary() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("AddLib");
		return mv;
	}
	
	@RequestMapping(value = "/addLib",method = RequestMethod.POST)
	public ModelAndView addLibrary(@ModelAttribute Library library) {
		System.out.println("inside add /n");
		ModelAndView mv = new ModelAndView();
		libService.addLibrary(library);
		//mv.setViewName("redirect:/");
		mv.addObject("data", "AddLibrary");
		mv.setViewName("Alert");
		return mv;
	}
	
	@GetMapping("/getLib/{lid}")
	public ModelAndView getLibraryById(@PathVariable int lid) {
		System.out.println("controller get by id +++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		Library library = libService.getLibraryById(lid);
		ModelAndView mv = new ModelAndView();
		mv.addObject("library", library);
		return mv;
	}
	
	//@DeleteMapping("/delLib/{lid}")
	@RequestMapping("/delLib/{lid}")
	public ModelAndView deleteLibrary(@PathVariable int lid) {
		libService.deleteLibrary(lid);
		ModelAndView mv = new ModelAndView("redirect:/");
		System.out.println("deleted");
		return mv;
	}
	
	@RequestMapping("/getEditLib/{lid}")
	public ModelAndView getEditLibrary(@PathVariable int lid) {
		ModelAndView mv = new ModelAndView("EditLibrary");
		//mv.addObject("lid", lid);
		Library lib = libService.getLibraryById(lid);
		mv.addObject("library", lib);
		System.out.println("\n hellloooooooooooooooooo \n"+lid);
		return mv;
	}
	@PostMapping("/getEditLib/editLib/{lid}")
	public ModelAndView update(@PathVariable int lid,@ModelAttribute Library library) {
		//System.out.println("update7777777777777777777777777777777--------" +lid+" "+library.getLibrary_Name());
		libService.updateLibrary(lid, library);
		System.out.println("updated");
		return new ModelAndView("Alert").addObject("data", "EditLibrary");
	}
	
	
	
//	@GetMapping
//	public ModelAndView getAllBooks() {
//		return 
//	}
	
	
	@GetMapping("/getNewBook")
	public ModelAndView getNewBook() {
		List<String> libNames = libService.getAllLibraryNames();
		return new ModelAndView("AddBook").addObject("libs", libNames);
	}
	
	@PostMapping("/addBook")
	public ModelAndView addBook(@ModelAttribute Book book,@RequestParam("libName") String libName) {
		bookService.addBook(book, libName);
		ModelAndView mv = new ModelAndView("Alert");
		mv.addObject("data", "AddBook");
		return mv;
	}
	
	@GetMapping("/delBook/{bid}")
	public ModelAndView deleteBook(@PathVariable int bid) {
		bookService.deleteBook(bid);
		return new ModelAndView("redirect:/");
	}
	
	@GetMapping("getEditBook/{bid}")
	public ModelAndView getNewBook(@PathVariable int bid) {
		Book book = bookService.getBookById(bid);
		return new ModelAndView("EditBook").addObject("bid", bid).addObject("book", book);
	}
	
	@PostMapping("getEditBook/editBook/{bid}")
	public ModelAndView updateBook(@PathVariable int bid, @ModelAttribute Book book) {
		bookService.updateBook(bid,book);
		System.out.println("update book");
		return new ModelAndView("Alert").addObject("data", "EditBook");
	}

}
