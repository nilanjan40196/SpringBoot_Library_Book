package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capg.model.Book;
import com.capg.model.Library;
import com.capg.repository.BookRepo;

@Service
@Transactional
public class BookService {
	
	@Autowired
	private BookRepo bookRepo;
	
	@Autowired
	private LibraryService libService;
	
	
	public void addBook(Book book,String libName) {
		Library library = libService.findByLibraryname(libName);
		book.setLibrary(library);
		bookRepo.save(book);
	}
	
	public List<Book> gelAllBooks(){
		return bookRepo.findAll();
	}
	
	public void deleteBook(int bid) {
		bookRepo.deleteById(bid);
	}
	
	public Book getBookById(int bid) {
		return bookRepo.getOne(bid);
	}

	public void updateBook(int bid, Book book) {
		Book oldBook = bookRepo.getOne(bid);
		book.setBook_Id(bid);
		book.setLibrary(oldBook.getLibrary());
		bookRepo.save(book);
	}
}
