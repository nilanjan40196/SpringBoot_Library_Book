package com.capg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capg.model.Library;
import com.capg.repository.LibraryRepo;

@Service
public class LibraryService {
	
	@Autowired
	private LibraryRepo libRepo;

	public List<Library> getAllLibrary() {
		
		return libRepo.findAll();
	}
	
	@Transactional
	public Library addLibrary(Library library) {
		
		return libRepo.save(library);
	}
	@Transactional
	public Library getLibraryById(int lid) 
	{
		return libRepo.getOne(lid);
	}
	@Transactional
	public void deleteLibrary(int lid) {
		libRepo.deleteById(lid);
	}
	
	@Transactional
	public void updateLibrary(int lib_Id,Library lib) {
		//System.out.println("inside libser");
		Library oldLibrary = libRepo.getOne(lib_Id);
		lib.setLibrary_Id(lib_Id);
		lib.setBooks(oldLibrary.getBooks());
		libRepo.save(lib);
	} 
	
	@Transactional
	public Library findByLibraryname(String libName) {
		return libRepo.findByLibraryname(libName);
	}
	@Transactional
	public List<String> getAllLibraryNames(){
		return libRepo.getAllLibraryname();
	}
}
