package com.capg.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class Book {
	
	@Id
	@GeneratedValue
	private int book_Id;
	public int getBook_Id() {
		return book_Id;
	}

	public void setBook_Id(int book_Id) {
		this.book_Id = book_Id;
	}

	@Column(nullable = false)
	private String book_Name;
	@Column(nullable = false)
	private String book_Author;
	@Column(nullable = false)
	private String book_Publisher;
	
	@ManyToOne
	@JsonBackReference
	private Library library;

	public String getBook_Name() {
		return book_Name;
	}

	public void setBook_Name(String book_Name) {
		this.book_Name = book_Name;
	}

	public String getBook_Author() {
		return book_Author;
	}

	public void setBook_Author(String book_Author) {
		this.book_Author = book_Author;
	}

	public String getBook_Publisher() {
		return book_Publisher;
	}

	public void setBook_Publisher(String book_Publisher) {
		this.book_Publisher = book_Publisher;
	}

	public Library getLibrary() {
		return library;
	}

	public void setLibrary(Library library) {
		this.library = library;
	}

	public Book(String book_Name, String book_Author, String book_Publisher, Library library) {
		super();
		this.book_Name = book_Name;
		this.book_Author = book_Author;
		this.book_Publisher = book_Publisher;
		this.library = library;
	}

	public Book() {
		super();
	}
	
	
	
	
	

}
