package com.capg.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
public class Library {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Lib_Id")
	private int library_Id;
	@Column(name = "Lib_Name",nullable = false)
	private String library_Name;
	
	public void setLibrary_Id(int library_Id) {
		this.library_Id = library_Id;
	}

	@OneToMany(mappedBy = "library",cascade = CascadeType.ALL)
	@JsonManagedReference
	private List<Book> books;
	
	
	public String getLibrary_Name() {
		return library_Name;
	}

	public void setLibrary_Name(String library_Name) {
		this.library_Name = library_Name;
	}

	public List<Book> getBooks() {
		return books;
	}

	public void setBooks(List<Book> books) {
		this.books = books;
	}

	public int getLibrary_Id() {
		return library_Id;
	}

	public Library() {
		super();
	}

	public Library(String library_Name, List<Book> books) {
		super();
		this.library_Name = library_Name;
		this.books = books;
	}

	
	

}
